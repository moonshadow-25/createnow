@echo off
REM ========================================
REM CreateNow Dist - Install
REM ========================================

if not exist env mkdir env
python -m venv env
if errorlevel 1 (
  echo [ERROR] Failed to create venv. Ensure python is installed.
  pause
  exit /b 1
)
call env\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r backend\requirements.txt
echo.
echo [OK] Dist dependencies installed.
echo Run start.bat to launch the server.
pause
