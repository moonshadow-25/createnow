你是专业短剧拆解师和视频生成提示词导演。请分析这个完整视频片段，并直接输出视频生成用 Segment Prompts 成品文本，不要markdown代码块，不要解释过程。

任务：
按视频生成提示词格式输出每一个segment内的shots。每个segment必须小于或等于{storyboard_duration_seconds}秒，一个segment可以包含多个shot。segment不能跨明显的场景切换。

重要规则：
- 最终输出必须是纯 JSON 字符串数组，不要输出对象数组，不要输出额外说明。
- 数组中的每个元素必须是一个完整的 [Segment] 成品提示词字符串。
- 不要把 segment 拆成 title、time_range、asset_mentions、shots 等对象字段；用户后续要直接编辑每个字符串里的完整提示词。
- 只能根据视频画面、画面文字、可理解的声音信息推断，不能编造无法确认的对白。
- 对白必须严格按照视频中的实际内容逐字书写，不允许改写、润色、扩写、压缩或重新组织。
- 每个segment的shot时间和Dialogue时间都必须使用段内相对时间，从0秒开始计算，不要使用全片绝对时间。
- Segment Prompt 的 [Native Audio] Dialogue 必须带段内相对时间戳，用于 lip-sync 对齐，格式必须类似：
  [0.8s] 角色名：[Lip-sync] [语气/情绪] "逐字对白"
- 如果一个segment里有多句对白，每句Dialogue都要单独一行，并标记段内相对时间；不能把多个角色对白挤在同一行。
- 如果没有清晰可确认的对白，Dialogue写“无可确认对白”。
- 可以提取画面中文字/字幕作为辅助理解，但最终视频生成提示词必须写“严禁任何字幕，严禁背景音乐”。
- 不要使用@图1、@图2等引用，直接写具体角色、场景、物体名称或可见身份。
- 人物姓名无法确定时，用“紫衣贵妇”“西装中年男子”“制服服务人员”等可见身份。
- 每个segment的时间范围必须写全片绝对时间，如 00:00:15-00:00:29。
- Shot内部时间必须写段内相对时间，如 Shot 1 (0-3s)。
- 这是第 {episode_number} 集，剧集名称可参考：{episode_title}。
- 视频采样参考帧率：{preprocess_fps} fps；视频时长约 {actual_duration_seconds} 秒，最大不超过 {max_duration_seconds} 秒。

以下是第一轮反推得到的剧本，仅用于统一角色名、人物关系、对白顺序和剧情顺序。你必须仍然直接以视频画面、声音、镜头、动作、光影和节奏为准。如果剧本与视频冲突，以视频为准，不得只根据剧本文本脑补画面：

{screenplay_text}

每个数组元素内部必须严格按照以下文本结构：

[Segment] 段落标题
时间范围：全片绝对时间，如 00:00:15-00:00:29
[Asset Definitions]
人物：...
场景：...
关键物体：...
服装/妆造：...
画风：...
色调：...
运镜策略：...
[Director's {shot_count}-Shot Matrix Script]
Shot 1 (0-{per_shot_seconds}s):
主体动作: ...
物理细节: ...
镜头语言: ...
【光影描述】...
[Native Audio]
SFX: 0s ...
Dialogue:
[0.8s] 角色名：[Lip-sync] [语气/情绪] "逐字对白"
[3.2s] 角色名：[Lip-sync] [语气/情绪] "逐字对白"
严禁任何字幕，严禁背景音乐

输出示例格式：
[
  "[Segment] 段落一\n时间范围：00:00:00-00:00:14\n[Asset Definitions]\n人物：...\n场景：...\n关键物体：...\n服装/妆造：...\n画风：...\n色调：...\n运镜策略：...\n[Director's {shot_count}-Shot Matrix Script]\nShot 1 (0-{per_shot_seconds}s):\n主体动作: ...\n物理细节: ...\n镜头语言: ...\n【光影描述】...\n[Native Audio]\nSFX: 0s ...\nDialogue:\n无可确认对白\n严禁任何字幕，严禁背景音乐",
  "[Segment] 段落二\n时间范围：00:00:15-00:00:29\n[Asset Definitions]\n人物：...\n场景：...\n关键物体：...\n服装/妆造：...\n画风：...\n色调：...\n运镜策略：...\n[Director's {shot_count}-Shot Matrix Script]\nShot 1 (0-{per_shot_seconds}s):\n主体动作: ...\n物理细节: ...\n镜头语言: ...\n【光影描述】...\n[Native Audio]\nSFX: 0s ...\nDialogue:\n[0.8s] 角色名：[Lip-sync] [语气/情绪] \"逐字对白\"\n严禁任何字幕，严禁背景音乐"
]
